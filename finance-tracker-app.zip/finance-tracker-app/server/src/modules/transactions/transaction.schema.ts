import { z } from 'zod';

// amount is accepted from the client in whole currency units (e.g. rupees/dollars)
// and converted to integer cents/paise before hitting the DB — never trust the
// client to send cents directly, since that's an easy place for a UI bug to
// silently store amounts 100x too large or small.
const amountSchema = z
  .number()
  .positive('Amount must be greater than 0')
  .multipleOf(0.01, 'Amount can have at most 2 decimal places');

export const createTransactionSchema = z.object({
  amount: amountSchema,
  type: z.enum(['INCOME', 'EXPENSE']),
  description: z.string().max(255).optional(),
  date: z.coerce.date(),
  categoryId: z.string().uuid().optional(),
});

export const updateTransactionSchema = z.object({
  amount: amountSchema.optional(),
  type: z.enum(['INCOME', 'EXPENSE']).optional(),
  description: z.string().max(255).optional(),
  date: z.coerce.date().optional(),
  categoryId: z.string().uuid().nullable().optional(),
});

export const listTransactionsQuerySchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().positive().max(100).default(20),
  type: z.enum(['INCOME', 'EXPENSE']).optional(),
  categoryId: z.string().uuid().optional(),
  startDate: z.coerce.date().optional(),
  endDate: z.coerce.date().optional(),
});

export type CreateTransactionInput = z.infer<typeof createTransactionSchema>;
export type UpdateTransactionInput = z.infer<typeof updateTransactionSchema>;
export type ListTransactionsQuery = z.infer<typeof listTransactionsQuerySchema>;
