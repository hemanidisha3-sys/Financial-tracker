import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../../utils/apiError';
import {
  createTransactionSchema,
  updateTransactionSchema,
  listTransactionsQuerySchema,
} from './transaction.schema';
import * as transactionService from './transaction.service';

// req.userId is set by the authenticateToken middleware on every route below —
// it's always present here, since these routes are never reachable otherwise.

export async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const parsed = createTransactionSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.issues[0].message });
    }

    const transaction = await transactionService.createTransaction(req.userId!, parsed.data);
    return res.status(201).json({ transaction });
  } catch (err) {
    if (err instanceof ApiError) {
      return res.status(err.statusCode).json({ error: err.message });
    }
    next(err);
  }
}

export async function list(req: Request, res: Response, next: NextFunction) {
  try {
    const parsed = listTransactionsQuerySchema.safeParse(req.query);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.issues[0].message });
    }

    const result = await transactionService.listTransactions(req.userId!, parsed.data);
    return res.status(200).json(result);
  } catch (err) {
    if (err instanceof ApiError) {
      return res.status(err.statusCode).json({ error: err.message });
    }
    next(err);
  }
}

export async function getById(req: Request, res: Response, next: NextFunction) {
  try {
    const transaction = await transactionService.getTransactionById(req.userId!, req.params.id);
    return res.status(200).json({ transaction });
  } catch (err) {
    if (err instanceof ApiError) {
      return res.status(err.statusCode).json({ error: err.message });
    }
    next(err);
  }
}

export async function update(req: Request, res: Response, next: NextFunction) {
  try {
    const parsed = updateTransactionSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.issues[0].message });
    }

    const transaction = await transactionService.updateTransaction(
      req.userId!,
      req.params.id,
      parsed.data
    );
    return res.status(200).json({ transaction });
  } catch (err) {
    if (err instanceof ApiError) {
      return res.status(err.statusCode).json({ error: err.message });
    }
    next(err);
  }
}

export async function remove(req: Request, res: Response, next: NextFunction) {
  try {
    await transactionService.deleteTransaction(req.userId!, req.params.id);
    return res.status(204).send();
  } catch (err) {
    if (err instanceof ApiError) {
      return res.status(err.statusCode).json({ error: err.message });
    }
    next(err);
  }
}

export async function summaryByCategory(req: Request, res: Response, next: NextFunction) {
  try {
    const summary = await transactionService.getSummaryByCategory(req.userId!);
    return res.status(200).json({ summary });
  } catch (err) {
    next(err);
  }
}
