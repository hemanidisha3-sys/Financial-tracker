import { Router } from 'express';
import { authenticateToken } from '../../middlewares/auth.middleware';
import * as transactionController from './transaction.controller';

const router = Router();

// Every route below requires a valid JWT — applied once here rather than
// per-route, so it's impossible to accidentally add a new route and forget
// to protect it.
router.use(authenticateToken);

router.post('/', transactionController.create);
router.get('/', transactionController.list);
router.get('/summary', transactionController.summaryByCategory);
router.get('/:id', transactionController.getById);
router.patch('/:id', transactionController.update);
router.delete('/:id', transactionController.remove);

export default router;
