import { Prisma } from '@prisma/client';
import { prisma } from '../../config/db';
import { ApiError } from '../../utils/apiError';
import {
  CreateTransactionInput,
  UpdateTransactionInput,
  ListTransactionsQuery,
} from './transaction.schema';

function toCents(amount: number): number {
  // Math.round guards against floating point weirdness like 19.99 * 100 = 1998.9999999999998
  return Math.round(amount * 100);
}

function toAmount(cents: number): number {
  return cents / 100;
}

// Shape returned to the client — converts amountCents back to a normal decimal
// amount so the frontend never has to think in cents.
function serializeTransaction(tx: {
  id: string;
  amountCents: number;
  type: string;
  description: string | null;
  date: Date;
  categoryId: string | null;
  createdAt: Date;
  updatedAt: Date;
}) {
  return {
    id: tx.id,
    amount: toAmount(tx.amountCents),
    type: tx.type,
    description: tx.description,
    date: tx.date,
    categoryId: tx.categoryId,
    createdAt: tx.createdAt,
    updatedAt: tx.updatedAt,
  };
}

// Confirms the category exists AND belongs to this user — without this check,
// user A could attach their transaction to user B's category id by guessing/
// reusing a UUID they saw elsewhere.
async function assertCategoryOwnership(categoryId: string, userId: string) {
  const category = await prisma.category.findUnique({ where: { id: categoryId } });
  if (!category || category.userId !== userId) {
    throw new ApiError('Category not found', 400);
  }
}

export async function createTransaction(userId: string, input: CreateTransactionInput) {
  if (input.categoryId) {
    await assertCategoryOwnership(input.categoryId, userId);
  }

  const tx = await prisma.transaction.create({
    data: {
      amountCents: toCents(input.amount),
      type: input.type,
      description: input.description,
      date: input.date,
      userId,
      categoryId: input.categoryId,
    },
  });

  return serializeTransaction(tx);
}

export async function listTransactions(userId: string, query: ListTransactionsQuery) {
  const where: Prisma.TransactionWhereInput = {
    userId,
    ...(query.type ? { type: query.type } : {}),
    ...(query.categoryId ? { categoryId: query.categoryId } : {}),
    ...(query.startDate || query.endDate
      ? {
          date: {
            ...(query.startDate ? { gte: query.startDate } : {}),
            ...(query.endDate ? { lte: query.endDate } : {}),
          },
        }
      : {}),
  };

  const [items, total] = await Promise.all([
    prisma.transaction.findMany({
      where,
      orderBy: { date: 'desc' },
      skip: (query.page - 1) * query.pageSize,
      take: query.pageSize,
    }),
    prisma.transaction.count({ where }),
  ]);

  return {
    items: items.map(serializeTransaction),
    pagination: {
      page: query.page,
      pageSize: query.pageSize,
      total,
      totalPages: Math.ceil(total / query.pageSize),
    },
  };
}

export async function getTransactionById(userId: string, id: string) {
  const tx = await prisma.transaction.findUnique({ where: { id } });

  // Same 404 whether the row doesn't exist or belongs to someone else —
  // never reveal that a transaction ID exists but "isn't yours".
  if (!tx || tx.userId !== userId) {
    throw new ApiError('Transaction not found', 404);
  }

  return serializeTransaction(tx);
}

export async function updateTransaction(
  userId: string,
  id: string,
  input: UpdateTransactionInput
) {
  const existing = await prisma.transaction.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) {
    throw new ApiError('Transaction not found', 404);
  }

  if (input.categoryId) {
    await assertCategoryOwnership(input.categoryId, userId);
  }

  const tx = await prisma.transaction.update({
    where: { id },
    data: {
      ...(input.amount !== undefined ? { amountCents: toCents(input.amount) } : {}),
      ...(input.type !== undefined ? { type: input.type } : {}),
      ...(input.description !== undefined ? { description: input.description } : {}),
      ...(input.date !== undefined ? { date: input.date } : {}),
      ...(input.categoryId !== undefined ? { categoryId: input.categoryId } : {}),
    },
  });

  return serializeTransaction(tx);
}

export async function deleteTransaction(userId: string, id: string) {
  const existing = await prisma.transaction.findUnique({ where: { id } });
  if (!existing || existing.userId !== userId) {
    throw new ApiError('Transaction not found', 404);
  }

  await prisma.transaction.delete({ where: { id } });
}

export async function getSummaryByCategory(userId: string) {
  const grouped = await prisma.transaction.groupBy({
    by: ['categoryId', 'type'],
    where: { userId },
    _sum: { amountCents: true },
  });

  return grouped.map((g) => ({
    categoryId: g.categoryId,
    type: g.type,
    total: toAmount(g._sum.amountCents ?? 0),
  }));
}
