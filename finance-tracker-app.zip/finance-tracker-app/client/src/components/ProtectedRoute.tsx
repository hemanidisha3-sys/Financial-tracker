import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function ProtectedRoute({ children }: { children: JSX.Element }) {
  const { user } = useAuth();
  const hasToken = Boolean(localStorage.getItem('token'));

  // Check the token directly too, not just `user` state — on a hard refresh,
  // context re-initializes from localStorage synchronously, but this keeps
  // the guard correct even if that logic ever changes.
  if (!user && !hasToken) {
    return <Navigate to="/login" replace />;
  }

  return children;
}
