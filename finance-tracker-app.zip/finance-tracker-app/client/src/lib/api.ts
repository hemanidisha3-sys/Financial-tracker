import axios from 'axios';

// Vite exposes env vars prefixed with VITE_ on import.meta.env at build time.
// Falls back to localhost:4000 so the app works out of the box in dev
// without requiring a .env file.
const baseURL = import.meta.env.VITE_API_URL ?? 'http://localhost:4000/api';

export const api = axios.create({ baseURL });

// Attach the JWT to every outgoing request automatically, so individual
// components never have to remember to pass the Authorization header.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// If the token is invalid/expired, the backend returns 401 — bounce back to
// login rather than showing a broken, half-authenticated screen.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);
