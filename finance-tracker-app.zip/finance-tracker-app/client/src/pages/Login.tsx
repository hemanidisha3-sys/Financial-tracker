import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.response?.data?.error ?? 'Something went wrong. Try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen grid md:grid-cols-2">
      <div className="hidden md:flex flex-col justify-between bg-forest text-paper p-12">
        <span className="font-serif text-2xl">Ledger</span>
        <div>
          <p className="font-serif text-3xl leading-snug max-w-sm">
            Know exactly where your money goes, every month.
          </p>
          <p className="mt-4 text-forest-light/80 max-w-sm text-sm">
            Track income and expenses in one place, without a spreadsheet.
          </p>
        </div>
        <span className="text-xs text-forest-light/60">
          A student project — not a bank.
        </span>
      </div>

      <div className="flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <h1 className="font-serif text-2xl mb-1">Welcome back</h1>
          <p className="text-sm text-ink/60 mb-8">Log in to see your finances.</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-md border border-sand px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-forest"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border border-sand px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-forest"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <p className="text-sm text-rust bg-rust-light rounded-md px-3 py-2">{error}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-forest text-paper rounded-md py-2 text-sm font-medium hover:bg-forest-dark transition-colors disabled:opacity-60"
            >
              {loading ? 'Logging in…' : 'Log in'}
            </button>
          </form>

          <p className="text-sm text-ink/60 mt-6">
            No account yet?{' '}
            <Link to="/register" className="text-forest font-medium hover:underline">
              Create one
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
