import { FormEvent, useEffect, useMemo, useState } from 'react';
import { api } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { Transaction, TransactionType } from '../types';

const currency = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 2,
});

export function Dashboard() {
  const { user, logout } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // form state
  const [amount, setAmount] = useState('');
  const [type, setType] = useState<TransactionType>('EXPENSE');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  async function loadTransactions() {
    setLoading(true);
    setError(null);
    try {
      const { data } = await api.get('/transactions', { params: { pageSize: 50 } });
      setTransactions(data.items);
    } catch {
      setError('Could not load transactions. Is the server running?');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadTransactions();
  }, []);

  const { totalIncome, totalExpense, balance } = useMemo(() => {
    const totalIncome = transactions
      .filter((t) => t.type === 'INCOME')
      .reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = transactions
      .filter((t) => t.type === 'EXPENSE')
      .reduce((sum, t) => sum + t.amount, 0);
    return { totalIncome, totalExpense, balance: totalIncome - totalExpense };
  }, [transactions]);

  async function handleAddTransaction(e: FormEvent) {
    e.preventDefault();
    setFormError(null);

    const parsedAmount = Number(amount);
    if (!amount || Number.isNaN(parsedAmount) || parsedAmount <= 0) {
      setFormError('Enter an amount greater than 0.');
      return;
    }

    setSubmitting(true);
    try {
      await api.post('/transactions', {
        amount: parsedAmount,
        type,
        description: description || undefined,
        date,
      });
      setAmount('');
      setDescription('');
      await loadTransactions();
    } catch (err: any) {
      setFormError(err.response?.data?.error ?? 'Could not add transaction.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete(id: string) {
    // Optimistic removal — the row disappears immediately rather than
    // waiting on the round trip, since a delete is very unlikely to fail.
    const previous = transactions;
    setTransactions((curr) => curr.filter((t) => t.id !== id));
    try {
      await api.delete(`/transactions/${id}`);
    } catch {
      setTransactions(previous);
      setError('Could not delete that transaction. Please try again.');
    }
  }

  return (
    <div className="min-h-screen flex">
      <aside className="w-56 shrink-0 bg-forest text-paper flex flex-col justify-between p-6">
        <div>
          <span className="font-serif text-xl">Ledger</span>
          <nav className="mt-10 space-y-1 text-sm">
            <span className="block rounded-md bg-forest-dark px-3 py-2 font-medium">
              Dashboard
            </span>
          </nav>
        </div>
        <div className="text-sm">
          <p className="text-forest-light/70 truncate">{user?.email}</p>
          <button
            onClick={logout}
            className="mt-2 text-forest-light/90 hover:text-paper underline underline-offset-2"
          >
            Log out
          </button>
        </div>
      </aside>

      <main className="flex-1 p-8 max-w-5xl">
        <h1 className="font-serif text-2xl mb-6">
          Hi{user?.name ? `, ${user.name}` : ''} — here's where you stand.
        </h1>

        <div className="grid sm:grid-cols-3 gap-4 mb-10">
          <SummaryCard label="Income" value={totalIncome} tone="forest" />
          <SummaryCard label="Expenses" value={totalExpense} tone="rust" />
          <SummaryCard label="Balance" value={balance} tone={balance >= 0 ? 'forest' : 'rust'} />
        </div>

        <section className="mb-10">
          <h2 className="font-serif text-lg mb-3">Add a transaction</h2>
          <form
            onSubmit={handleAddTransaction}
            className="flex flex-wrap items-end gap-3 bg-white border border-sand rounded-lg p-4"
          >
            <div className="flex gap-1 bg-sand/40 rounded-md p-1">
              {(['EXPENSE', 'INCOME'] as TransactionType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
                    type === t
                      ? t === 'EXPENSE'
                        ? 'bg-rust text-paper'
                        : 'bg-forest text-paper'
                      : 'text-ink/60 hover:text-ink'
                  }`}
                >
                  {t === 'EXPENSE' ? 'Expense' : 'Income'}
                </button>
              ))}
            </div>

            <div className="w-32">
              <label className="block text-xs text-ink/60 mb-1">Amount</label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full rounded-md border border-sand px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-forest"
                placeholder="0.00"
              />
            </div>

            <div className="flex-1 min-w-[160px]">
              <label className="block text-xs text-ink/60 mb-1">
                Description <span className="text-ink/40">(optional)</span>
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full rounded-md border border-sand px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-forest"
                placeholder="Groceries, salary, rent…"
              />
            </div>

            <div className="w-40">
              <label className="block text-xs text-ink/60 mb-1">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full rounded-md border border-sand px-2 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-forest"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="bg-ink text-paper rounded-md px-4 py-1.5 text-sm font-medium hover:bg-ink/80 transition-colors disabled:opacity-60"
            >
              {submitting ? 'Adding…' : 'Add'}
            </button>

            {formError && <p className="w-full text-sm text-rust">{formError}</p>}
          </form>
        </section>

        <section>
          <h2 className="font-serif text-lg mb-3">Recent transactions</h2>

          {loading && <p className="text-sm text-ink/50">Loading…</p>}
          {error && <p className="text-sm text-rust">{error}</p>}

          {!loading && !error && transactions.length === 0 && (
            <p className="text-sm text-ink/50 border border-dashed border-sand rounded-lg p-8 text-center">
              No transactions yet. Add your first one above.
            </p>
          )}

          {!loading && transactions.length > 0 && (
            <div className="border border-sand rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-sand/30 text-left text-ink/60">
                    <th className="px-4 py-2 font-medium">Date</th>
                    <th className="px-4 py-2 font-medium">Description</th>
                    <th className="px-4 py-2 font-medium">Type</th>
                    <th className="px-4 py-2 font-medium text-right">Amount</th>
                    <th className="px-4 py-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((t) => (
                    <tr key={t.id} className="border-t border-sand">
                      <td className="px-4 py-2 text-ink/70">
                        {new Date(t.date).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </td>
                      <td className="px-4 py-2">{t.description || '—'}</td>
                      <td className="px-4 py-2">
                        <span
                          className={`inline-block rounded px-2 py-0.5 text-xs font-medium ${
                            t.type === 'INCOME'
                              ? 'bg-forest-light text-forest-dark'
                              : 'bg-rust-light text-rust'
                          }`}
                        >
                          {t.type === 'INCOME' ? 'Income' : 'Expense'}
                        </span>
                      </td>
                      <td
                        className={`px-4 py-2 text-right tabular-nums font-medium ${
                          t.type === 'INCOME' ? 'text-forest-dark' : 'text-rust'
                        }`}
                      >
                        {t.type === 'INCOME' ? '+' : '−'}
                        {currency.format(t.amount)}
                      </td>
                      <td className="px-4 py-2 text-right">
                        <button
                          onClick={() => handleDelete(t.id)}
                          className="text-ink/40 hover:text-rust text-xs"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

function SummaryCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: 'forest' | 'rust';
}) {
  return (
    <div className="border border-sand rounded-lg p-4 bg-white">
      <p className="text-xs text-ink/50 mb-1">{label}</p>
      <p
        className={`font-serif text-2xl tabular-nums ${
          tone === 'forest' ? 'text-forest-dark' : 'text-rust'
        }`}
      >
        {currency.format(value)}
      </p>
    </div>
  );
}
