/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1C2321',
        paper: '#FBFBF8',
        forest: {
          DEFAULT: '#2F6F4E',
          dark: '#234F39',
          light: '#E7F0EA',
        },
        rust: {
          DEFAULT: '#B3492F',
          light: '#F5E7E2',
        },
        sand: '#E7E2D6',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        serif: ['Fraunces', 'Georgia', 'serif'],
      },
    },
  },
  plugins: [],
};
