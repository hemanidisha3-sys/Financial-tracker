# Finance Tracker — Easy Setup

Everything you need is in this one folder. No terminal typing required for setup — just double-click two files.

## First-time setup (only do this once)

1. **Unzip this whole folder** somewhere simple, like directly on your Desktop or in `C:\Projects\`. Avoid unzipping it inside another folder that already has the same name — that's what caused problems before.
2. Open the folder and **double-click `install.bat`**. A black window will open and install everything. Wait for it to say "Install complete!" and press any key to close it.
3. It will have created a file called `server\.env`. Open that file in Notepad (right-click → Open with → Notepad) and fill in:
   - `DATABASE_URL` — your Neon connection string (the one you set up before, looks like `postgresql://...neon.tech/...`)
   - `JWT_SECRET` — any long random string. You can generate one by opening a terminal in the `server` folder and running:
     ```
     node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
     ```
   Save and close Notepad.
4. Open a terminal in the `server` folder and run:
   ```
   npx prisma migrate dev --name init
   ```
   This creates your database tables. (This one step still needs a terminal, since it's a one-time database action — everything else is double-click from here on.)

## Every time you want to work on it

**Double-click `start.bat`.** Two windows will open — one for the backend, one for the frontend. Wait until both say they're running, then open:

```
http://localhost:5173
```

in your browser. That's your website.

To stop, just close both black windows (or press Ctrl+C in each).

## If something goes wrong

Come back to this chat, tell me exactly what error message you see (a screenshot is even better), and I'll help you fix it.
