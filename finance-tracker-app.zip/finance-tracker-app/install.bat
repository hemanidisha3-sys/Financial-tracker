@echo off
echo ============================================
echo   Installing Finance Tracker dependencies
echo ============================================
echo.

echo [1/2] Installing backend (server) packages...
cd server
call npm install
if errorlevel 1 (
    echo.
    echo Something went wrong installing the backend. Scroll up to see the error.
    pause
    exit /b 1
)
cd ..

echo.
echo [2/2] Installing frontend (client) packages...
cd client
call npm install
if errorlevel 1 (
    echo.
    echo Something went wrong installing the frontend. Scroll up to see the error.
    pause
    exit /b 1
)
cd ..

echo.
if not exist "server\.env" (
    echo Creating server\.env from the template...
    copy server\.env.example server\.env >nul
    echo.
    echo ============================================
    echo   IMPORTANT: open server\.env in Notepad and
    echo   fill in your DATABASE_URL and JWT_SECRET
    echo   before running start.bat
    echo ============================================
) else (
    echo server\.env already exists - leaving it as is.
)

echo.
echo Install complete! Next, double-click start.bat
echo.
pause
