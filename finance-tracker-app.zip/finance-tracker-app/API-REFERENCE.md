# Personal Finance Tracker

Full-stack app: React (Vite, TypeScript, Tailwind) + Node/Express (TypeScript) + PostgreSQL/Prisma.

## Structure

```
personal-finance-tracker/
├── client/    # React frontend (scaffold with `npm create vite@latest client -- --template react-ts`)
└── server/    # Express + Prisma backend (included here)
```

> This download includes both the **server** (auth + transactions API) and the **client** (React dashboard) fully scaffolded and wired together.

## Quick start (both apps)

**Terminal 1 — backend:**
```bash
cd server
npm install
cp .env.example .env   # then fill in DATABASE_URL and JWT_SECRET
npx prisma migrate dev --name init
npm run dev             # http://localhost:4000
```

**Terminal 2 — frontend:**
```bash
cd client
npm install
npm run dev              # http://localhost:5173
```

Open `http://localhost:5173` in your browser — register an account, log in, and you'll land on the dashboard where you can add and delete transactions against your real database.

## Auth endpoints

| Method | Route                | Body                                | Notes                          |
|--------|----------------------|--------------------------------------|---------------------------------|
| POST   | `/api/auth/register` | `{ email, password, name? }`         | Returns `{ user, token }`, 201 |
| POST   | `/api/auth/login`    | `{ email, password }`                | Returns `{ user, token }`, 200 |

Protect any route with the `authenticateToken` middleware:

```ts
import { authenticateToken } from '../../middlewares/auth.middleware';
router.get('/transactions', authenticateToken, getTransactions);
// inside the handler: req.userId
```

## Transaction endpoints (all require `Authorization: Bearer <token>`)

| Method | Route                       | Body / Query                                              | Notes                                   |
|--------|------------------------------|------------------------------------------------------------|------------------------------------------|
| POST   | `/api/transactions`          | `{ amount, type, description?, date, categoryId? }`         | `amount` is a normal decimal (e.g. `19.99`), stored as cents internally |
| GET    | `/api/transactions`          | `?page=1&pageSize=20&type=&categoryId=&startDate=&endDate=` | Paginated, filterable, sorted by date desc |
| GET    | `/api/transactions/summary`  | —                                                            | Totals grouped by category + type       |
| GET    | `/api/transactions/:id`      | —                                                            | 404 if it doesn't exist or isn't yours  |
| PATCH  | `/api/transactions/:id`      | Any subset of the POST fields                                | Partial update                          |
| DELETE | `/api/transactions/:id`      | —                                                            | Returns 204 on success                  |

Every route checks that the transaction (and any `categoryId` you pass) belongs to the logged-in user — you'll get a 404/400 rather than another user's data.

## Generate a JWT secret

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```
