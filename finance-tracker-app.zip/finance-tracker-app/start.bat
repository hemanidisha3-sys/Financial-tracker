@echo off
if not exist "server\.env" (
    echo.
    echo ============================================
    echo   server\.env is missing!
    echo   Run install.bat first, then edit
    echo   server\.env with your database details.
    echo ============================================
    echo.
    pause
    exit /b 1
)

echo Starting backend on http://localhost:4000 ...
start "Finance Tracker - Backend" cmd /k "cd server && npm run dev"

timeout /t 3 /nobreak >nul

echo Starting frontend on http://localhost:5173 ...
start "Finance Tracker - Frontend" cmd /k "cd client && npm run dev"

echo.
echo Two new windows just opened - one for the backend, one for the frontend.
echo Leave both running. Once you see "Server running" and "Local: http://localhost:5173"
echo in those windows, open this in your browser:
echo.
echo     http://localhost:5173
echo.
pause
